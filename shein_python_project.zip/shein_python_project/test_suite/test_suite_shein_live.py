import unittest
from test_case.test_shein_live.test_creat_Live import CreatLive
from test_case.test_shein_live.test_valid_preview import ValidPreview
from test_case.test_shein_live.test_valid_live import ValidLive
from test_case.test_shein_live.test_creat_prize_draw import CretaPrizeDraw
from test_case.test_shein_live.test_creat_redpacket import CreatRedpacket
from test_case.test_shein_live.test_create_box import CreateBox
from test_case.test_shein_live.test_create_vote import CreateVote
from test_case.test_shein_live.test_creat_official_message import CreatOfficialMessage
from test_case.test_shein_live.test_goods_show_one import GoodsShowOne
from test_case.test_shein_live.test_start_push_message import StartPushMessage
from test_case.test_shein_live.test_send_preview_comment import SendPreviewComment
from test_case.test_shein_live.test_im_comment_message import ImCommentMessage
from test_case.test_shein_live.test_send_redpacket import SendRedpacket
from test_case.test_shein_live.test_start_next_box import StartNextBox
from test_case.test_shein_live.test_start_prize import StartPrize
from test_case.test_shein_live.test_send_point import SendPoint
from test_case.test_shein_live.test_start_next_vote import StartNextVote
from test_case.test_shein_live.test_goods_show_more import GoodsShowMore
from test_case.test_shein_live.test_comment_send_points import CommentSendPoints
from test_case.test_shein_live.test_add_blacklist import AddBlacklist
from test_case.test_shein_live.test_delete_blacklist import DeleteBlacklist
from test_case.test_shein_live.test_end_live import EndLive
from test_case.test_shein_live.test_valid_playback import ValidPlayback
from test_case.test_shein_live.test_invalid_playback import InvalidPlayback
from test_case.test_shein_live.test_delete_live import DeleteLive
from common.basic_setting import BasicSetting


# 测试套件
# 添加测试用例（类名+测试方法名）
# suite.addTest(Get_Customer_List('test_operation_get_customer_list'))
# 添加测试用例（文件名+类名）
# suite.addTest(unittest.makeSuite(test_operation_get_groupchat_list.Woperation_get_groupchat_list))
def suite_shein_live():
    # 构造测试集
    suite = unittest.TestSuite()

    if BasicSetting().type == 'shein':

        # 创建shein直播预告
        suite.addTest(CreatLive('test_creat_live'))
        # shein直播预告开启
        suite.addTest(ValidPreview('test_valid_preview'))
        #直播预告发送弹幕
        suite.addTest(SendPreviewComment('test_shein'))
        # 转直播间
        suite.addTest(ValidLive('test_valid_live'))
        # 创建抽奖
        suite.addTest(CretaPrizeDraw('test_creat_prize_draw'))
        # 创建抢红包Points Giveaway-随机，平均积分-test_creat_redpacket
        suite.addTest(CreatRedpacket('test_creat_redpacket'))
        # 创建礼盒雨GIFT BOX RAIN-test_create_box
        suite.addTest(CreateBox('test_create_box'))
        # 创建三种投票，商品，图片，文字-test_create_vote
        suite.addTest(CreateVote('test_create_vote_picture'))
        suite.addTest(CreateVote('test_create_vote_product'))
        suite.addTest(CreateVote('test_create_vote_text'))
        # 发送直播官方消息-test_creat_official_message
        suite.addTest(CreatOfficialMessage('test_creat_official_message'))
        # 设置单个直播的悬浮商品-test_goods_show_one
        suite.addTest(GoodsShowOne('test_goods_show_one'))
        # 开始推流素材-test_start_push_message
        suite.addTest(StartPushMessage('test_start_push_message'))
        #直播间发送弹幕
        suite.addTest(ImCommentMessage('test_shein'))
        #开始抢红包
        suite.addTest(SendRedpacket('test_shein'))
        #开始礼盒雨
        suite.addTest(StartNextBox('test_shein'))
        #开始抽奖
        suite.addTest(StartPrize('test_shein'))
        #发送抽奖积分
        suite.addTest(SendPoint('test_shein'))
        #开始投票
        suite.addTest(StartNextVote('test_shein'))
        #设置多个直播的悬浮商品
        suite.addTest(GoodsShowMore('test_shein'))
        #对评论进行发积分
        suite.addTest(CommentSendPoints('test_shein'))
        #社区后台-直播间评论拉黑
        suite.addTest(AddBlacklist('test_shein'))
        #社区后台-直播间取消拉黑
        suite.addTest(DeleteBlacklist('test_shein'))
        #测试环境shein直播间转直播回放
        suite.addTest(EndLive('test_shein'))
        #测试环境shein直播回放开启
        suite.addTest(ValidPlayback('test_shein'))
        #测试环境shein直播回放关闭
        suite.addTest(InvalidPlayback('test_shein'))
        #测试环境删除shein直播回放
        suite.addTest(DeleteLive('test_shein'))

    elif BasicSetting().type=='romwe':
        # 创建shein直播预告
        suite.addTest(CreatLive('test_creat_live'))
        # shein直播预告开启
        suite.addTest(ValidPreview('test_valid_preview'))
        # 直播预告发送弹幕
        suite.addTest(SendPreviewComment('test_shein'))
        # 转直播间
        suite.addTest(ValidLive('test_valid_live'))
        # 创建抽奖
        suite.addTest(CretaPrizeDraw('test_creat_prize_draw'))
        # 创建抢红包Points Giveaway-随机，平均积分-test_creat_redpacket
        suite.addTest(CreatRedpacket('test_creat_redpacket'))
        # 创建礼盒雨GIFT BOX RAIN-test_create_box
        suite.addTest(CreateBox('test_create_box'))
        # 创建三种投票，商品，图片，文字-test_create_vote
        suite.addTest(CreateVote('test_create_vote_picture'))
        suite.addTest(CreateVote('test_create_vote_product'))
        suite.addTest(CreateVote('test_create_vote_text'))
        # 发送直播官方消息-test_creat_official_message
        suite.addTest(CreatOfficialMessage('test_creat_official_message'))
        # 设置单个直播的悬浮商品-test_goods_show_one
        suite.addTest(GoodsShowOne('test_goods_show_one'))
        # 开始推流素材-test_start_push_message
        # suite.addTest(StartPushMessage('test_start_push_message'))
        # 直播间发送弹幕
        suite.addTest(ImCommentMessage('test_shein'))
        # 开始抢红包
        suite.addTest(SendRedpacket('test_shein'))
        # 开始礼盒雨
        suite.addTest(StartNextBox('test_shein'))
        # 开始抽奖
        suite.addTest(StartPrize('test_shein'))
        # 发送抽奖积分
        suite.addTest(SendPoint('test_shein'))
        # 开始投票
        suite.addTest(StartNextVote('test_shein'))
        # 设置多个直播的悬浮商品
        suite.addTest(GoodsShowMore('test_shein'))
        # 对评论进行发积分
        suite.addTest(CommentSendPoints('test_shein'))
        # 社区后台-直播间评论拉黑
        suite.addTest(AddBlacklist('test_shein'))
        # 社区后台-直播间取消拉黑
        suite.addTest(DeleteBlacklist('test_shein'))
        # 测试环境shein直播间转直播回放
        suite.addTest(EndLive('test_shein'))
        # 测试环境shein直播回放开启
        suite.addTest(ValidPlayback('test_shein'))
        # 测试环境shein直播回放关闭
        suite.addTest(InvalidPlayback('test_shein'))
        # 测试环境删除shein直播回放
        suite.addTest(DeleteLive('test_shein'))

    return suite

    # 运行测试集合
    # runner = unittest.TextTestRunner()
    # runner.run(suite)
