from test_case.test_shein_live import *
from common.basic_setting import BasicSetting

if __name__ == '__main__':

    if BasicSetting().type=='shein':
        #预告
        CreatLive().test_creat_live()
        ValidPreview().test_valid_preview()
        SendPreviewComment().test_shein()
        print('enter')
        input()

        #转直播，创建活动
        ValidLive().test_valid_live()
        CretaPrizeDraw().test_creat_prize_draw()
        CreatRedpacket().test_creat_redpacket()
        CreateBox().test_create_box()
        CreateVote().test_create_vote_text()
        CreateVote().test_create_vote_picture()
        CreateVote().test_create_vote_product()
        CreatOfficialMessage().test_creat_official_message()
        GoodsShowOne().test_goods_show_one()
        StartPushMessage().test_start_push_message()
        print('enter')
        input()

        #发直播弹幕
        ImCommentMessage().test_shein()
        print('enter')
        input()

        #抢红包
        SendRedpacket().test_shein()
        print('enter')
        input()

        #礼盒雨
        StartNextBox().test_shein()
        print('enter')
        input()

        #抽奖
        StartPrize().test_shein()
        print('enter')
        input()

        #发抽奖积分
        SendPoint().test_shein()
        print('enter')
        input()

        #投票
        StartNextVote().test_shein()
        print('enter')
        input()

        #多个悬浮商品
        GoodsShowMore().test_shein()
        print('enter')
        input()

        #发送弹幕积分
        CommentSendPoints().test_shein()
        print('enter')
        input()

        #加弹幕黑名单
        AddBlacklist().test_shein()
        print('enter')
        input()

        #去除弹幕黑名单
        DeleteBlacklist().test_shein()
        print('enter')
        input()

        #回放
        EndLive().test_shein()
        ValidPlayback().test_shein()
        print('enter')
        input()

        #数据清理
        InvalidPlayback().test_shein()
        DeleteLive().test_shein()
        print('end')


    elif BasicSetting().type=='romwe':
        # 预告
        CreatLive().test_creat_live()
        ValidPreview().test_valid_preview()
        SendPreviewComment().test_shein()
        print('enter')
        input()

        # 转直播，创建活动
        ValidLive().test_valid_live()
        CretaPrizeDraw().test_creat_prize_draw()
        CreatRedpacket().test_creat_redpacket()
        CreateBox().test_create_box()
        CreateVote().test_create_vote_text()
        CreateVote().test_create_vote_picture()
        CreateVote().test_create_vote_product()
        CreatOfficialMessage().test_creat_official_message()
        GoodsShowOne().test_goods_show_one()
        # StartPushMessage().test_start_push_message()
        print('enter')
        input()

        # 发直播弹幕
        ImCommentMessage().test_shein()
        print('enter')
        input()

        # 抢红包
        SendRedpacket().test_shein()
        print('enter')
        input()

        # 礼盒雨
        StartNextBox().test_shein()
        print('enter')
        input()

        # 抽奖
        StartPrize().test_shein()
        print('enter')
        input()

        # 发抽奖积分
        SendPoint().test_shein()
        print('enter')
        input()

        # 投票
        StartNextVote().test_shein()
        print('enter')
        input()

        # 多个悬浮商品
        GoodsShowMore().test_shein()
        print('enter')
        input()

        # 发送弹幕积分
        CommentSendPoints().test_shein()
        print('enter')
        input()

        # 加弹幕黑名单
        AddBlacklist().test_shein()
        print('enter')
        input()

        # 去除弹幕黑名单
        DeleteBlacklist().test_shein()
        print('enter')
        input()

        # 回放
        EndLive().test_shein()
        ValidPlayback().test_shein()
        print('enter')
        input()

        # 数据清理
        InvalidPlayback().test_shein()
        DeleteLive().test_shein()
        print('end')

