import csv
import random
import time
import datetime


class CsvOperate():
    def csv_writer(num):
        '''
        写csv文件操作
        :return:
        '''
        # 定义第一行表头
        header = []
        # 某一行的数据
        line = []
        # 所有行的数据
        rows = []
        # 每一行的元素
        row1 = ''
        row2 = ''

        for i in range(num):
            # num 为需要写入多少行
            row1 = ''
            row2 = ''

            line.append(row1)
            line.append(row2)

            rows.append(line)

            i += 1

        with open(r'../test_data/writer_csv', mode='w', newline='') as f:  # newline=" "是为了避免写入之后有空行
            ff = csv.writer(f)

            ff.writerow(header)

            ff.writerows(rows)

            print('已成功写入csv')

        f.close()

    def csv_read():
        '''
        读csv文件操作
        :return:
        '''
        with open(r'文件路径', mode='r') as f:
            ff = csv.reader(f)
            # 获取每一行
            for i in ff:
                print(ff)
                # 获取某一列
                print(i[0])

            # 获取某一行
            ff_list = list(ff)
            print(ff_list[0])

        f.close()

        def more_writer_csv(num):
            '''
            批量写入csv文件
            :param num:
            :return:
            '''

            cxstartime = datetime.datetime.now()

            # 定义第一行表头
            header = ['手机号', 'unionid', '时间', '文本', '选择']

            rows = []
            row_list = []

            for i in range(num):
                # num为需要写入多少条数据

                # 手机号
                a = '130' + str(random.randint(10000000, 99999999))
                # unionid
                b = ''
                b_copy = 'ABCDEFGHIGKLMNOPQRSTUVWXYZabcdefghigklmnopqrstuvwxyz0123456789'
                for i in range(12):
                    b += b_copy[random.randint(0, len(b_copy) - 1)]
                # 时间
                c = ''
                # 设置时间元组
                c_startime = (2015, 1, 1, 0, 0, 0, 0, 0, 0)
                c_startime_timestamp = int(time.mktime(c_startime))
                c_endtime = (2021, 5, 1, 23, 59, 59, 0, 0, 0)
                # 转换成时间戳
                c_endtime_timestamp = int(time.mktime(c_endtime))
                for i in range(10):
                    # 随机抽取一个时间戳，再转换成时间元组，再转换成格式化字符串
                    c = time.strftime('%Y-%m-%d %H:%M:%S',
                                      time.localtime(random.randint(c_startime_timestamp, c_endtime_timestamp)))
                # 文本
                d = ''
                d_copy = '百度拥有数万名研发工程师，这是中国乃至全球都顶尖的技术着世界上最为先进的搜索引擎技斯、全球仅有的4个拥有搜索引擎核心技术的国家之一'
                for i in range(12):
                    d += d_copy[random.randint(0, len(d_copy) - 1)]
                # 选择
                e = ''
                e_copy = ['钻石', '黄金', '白银', '青铜']
                e = random.choice(e_copy)
                # 组装成一个list
                row_list.append(a)
                row_list.append(b)
                row_list.append(c)
                row_list.append(d)
                row_list.append(e)
                # 组装成一行数据，也是一个list
                rows.append(row_list)
                row_list = []

                i += 1

            with open(r'../data/csvdir.csv', mode='w', newline='')as f:  # newline=" "是为了避免写入之后有空行

                ff = csv.writer(f)


                ff.writerow(header)

                ff.writerows(rows)

                f.close()

                print('已成功写入csv')

                cxendtime = datetime.datetime.now()
                yxtime = (cxstartime - cxendtime).seconds
                print(yxtime)

# if __name__ == '__main__':
#     CsvOperate.csv_writer(5)
#     CsvOperate.csv_read()
#     CsvOperate.csv_read
