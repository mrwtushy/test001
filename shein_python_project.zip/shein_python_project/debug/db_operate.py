import pymysql
from sshtunnel import SSHTunnelForwarder


class DbOperate():
    def public_db():
        '''
        常规连接数据方法
        :return:
        '''
        # 连接数据库
        conn = pymysql.connect(host='gz-cdb-8qnojo9t.sql.tencentcdb.com', port=59113, user='root',
                               password='L9iizoMMod&G6nXpGiD!lwo!4x@0IW', db='we_customer')
        # 创建游标
        cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
        # 执行sql
        execute = cursor.execute('select * from code_ditch where name like "测试%" order by create_time desc')
        # 接收结果
        result = cursor.fetchall()
        print(result)
        # 关闭游标
        cursor.close()
        # 断开数据库
        conn.close()

    def ssh_db():
        '''
        使用ssh连接数据库方法
        :return:
        '''
        server = SSHTunnelForwarder(
            # 跳板机IP，跳板机端口号
            ('106.53.151.200', 22),
            ssh_username='yushuohuan',
            ssh_password='yushuohuan',
            # 如果验证方式是公钥的话可以使用下面的参数
            ssh_pkey=r'C:\Users\shy\.ssh\id_rsa',  # 私钥文件位置
            ssh_private_key_password='',  # 私钥密码(通行短语)
            remote_bind_address=('172.20.1.10', 3306)  # 远程数据库的IP和端口
        )
        server.start()
        # host必须为127.0.0.1，代表本机(堡垒机)，user和passwd填的是远程数据库的账号密码
        conn = pymysql.connect(host='127.0.0.1', port=server.local_bind_port, user='we_customer',
                               passwd='xvmmsrrsdbqiogp(Farbjslhmlgr8Js5', db='we_customer')
        # 创建游标
        cur = conn.cursor(cursor=pymysql.cursors.DictCursor)
        # 执行sql语句
        cur.execute(
            "select * from crop_tag where crop_tag_groups_id = (select id from crop_tag_group where qw_group_name = 'bbb')")
        # 返回所有结果
        res = cur.fetchall()
        print(res)
        # 关闭游标
        cur.close()
        # 关闭连接
        conn.close()
        # 关闭服务
        server.close()
