import re

a = 'ab12\__3中3_77'
a_regular = '.._*'

print(re.match(a_regular,a).group())

print(re.findall(a_regular,a))

b = 'yy1_菠'
b_regular = '.1*'
print(re.match(b_regular,b).group())
print(re.findall(b_regular,b))