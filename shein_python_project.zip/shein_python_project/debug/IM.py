import uuid
import random

from locust import User, TaskSet, between, task, HttpUser


class MessageTask(TaskSet):
    @task(1)
    def comment_message(self):
        """
        普通消息发送
        """
        params = {
            "content": "test",
            "deviceId": str(uuid.uuid1()),
            "lang": "en_us",
            "liveId": 2353,
            "nickname": "lanyu",
            "site": "iosshus",
            "siteUid": "iosshus",
            "source": "shein",
            "token": "ipsam voluptatem nobis a",
            "uid": random.randint(10000, 9999999)
        }
        a = self.client.post("/social/live/im/comment-message",json = params)
        print("comment_message")
        print(a.text)



    @task(1)
    def add_cart_message(self):
        """
        加车消息发送
        """
        params = {
            "deviceId": str(uuid.uuid1()),
            "goodsId": 339958,
            "lang": "en_us",
            "liveId": 2353,
            "nickname": "test",
            "quantity": 1,
            "site": "iosshus",
            "source": "shein",
            "uid": random.randint(10000, 9999999)
        }

        a = self.client.post("/social/live/im/add-cart-message", json=params)
        print("add_cart_message")
        print(a.text)


class WebUser(HttpUser):
    wait_time = between(0.1, 0.2)
    tasks = {MessageTask: 1}


if __name__ == "__main__":
    import os

    """
    线上地址：http://social-livecast-platform.shein.com
    测试环境地址：http://social-livecast-platform-test01.shein.com

    调试网址：http://httpbin.org
    不同的请求方式的path是对应请求方式，例如：/get,/post,/put,/delete,

    """
    os.system(
        "locust -f test_1.py --host=http://social-livecast-platform-test01.shein.com")
