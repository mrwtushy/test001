import logging
import requests
import selenium
import pymysql
import htmlrunner
import os

def tes1():
    a =1
    b = a+1
    print(b)
    logging.info('running')

def test2():
    '''获取当前工作的父目录 ！注意是父目录路径'''
    a=os.path.abspath('..')
    b=os.path.join(a,'test_data','one')
    print(a)
    print(b)

if __name__ == '__main__':
    test2()