import requests
import unittest
import json
from comm import env_url,operation_login_header,weike_db

class Get_Customer_List(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.weike_db = weike_db.Weike_db()
        self.env = env_url.EnvUrl().url()
        self.comm_header = operation_login_header.GltToken().comm_header()
        self.url = self.env + 'operation_get_customer_list'
        print('开始')
    @classmethod
    def tearDownClass(self):
        print('结束')
    def test_operation_get_customer_list(self):
        '''
        无条件查询
        :return:
        '''
        self.data = {"page":1,"page_size":10}
        res = requests.post(self.url,json.dumps(self.data),headers=self.comm_header)
        # self.assertNotEqual(0,res.json()['data']['total_num'],'无条件查询时，数据为空')
        execute_sql = self.weike_db.weike_db("select count(qw_external_userid) as a from member_customer")
        expect_d = execute_sql[0]['a']
        actual_d = res.json()['data']['total_num']
        self.assertEqual(expect_d,actual_d,'无条件查询时，数据为空')
    def test_members_operation_get_customer_list(self):
        '''
        用成员条件进行查询
        :return:
        '''
        # self.data = {"page":1,"page_size":10,"keyword":"","members":["YuShuoHuan"]}
        self.data = {"page":1,"page_size":10,"members":["YuShuoHuan"]}
        res =requests.post(self.url,json.dumps(self.data),headers=self.comm_header)
        #期望值
        execute_sql = self.weike_db.weike_db("select count(qw_external_userid) as a from member_customer where qw_userid = 'YuShuoHuan';")
        expect_d = execute_sql[0]['a']
        #实际值
        actual_d = res.json()['data']['total_num']
        # self.assertNotEqual(0,res.json()['data']['total_num'],'跟进成员条件查询时，数据为空')
        self.assertEqual(expect_d,actual_d,'跟进成员条件查询时，数据为空')
if __name__ == '__main__':
    #启动单元测试
    unittest.main()
    # # 获取TestSuite的实例对象
    # suite = unittest.TestSuite()
    # # 将测试用例添加到测试容器中
    # suite.addTest(Get_Customer_List('test_operation_get_customer_list'))
    # suite.addTest(Get_Customer_List('test_members_operation_get_customer_list'))
    # # 创建TextTestRunner类的实例对象
    # runner = unittest.TextTestRunner()
    # runner.run(suite)
