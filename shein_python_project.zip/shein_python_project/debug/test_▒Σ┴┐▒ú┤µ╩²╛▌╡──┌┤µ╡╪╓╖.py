a = 'ab'
#变量保存数据的内存地址
print("数据%s的内存地址是：%d"%(a,id('ab')))
print('a变量保存数据的内存地址是:%d'%id(a))
def test(num):
    print('函数内部%s对应的内存地址是:%d' %(num,id(a)))
    result = 123
    print("函数要返回数据的内存地址是:%d"%id(result))
    return result
r = test(a)
print("%d返回数据的内存地址是:%d"%(r,id(r)))
a = [1,2]
print("列表%s的内存地址:%d"%(a,id(a)))
a.append(3)
print("操作列表后%s的内存地址:%d"%(a,id(a)))


