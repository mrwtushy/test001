from appium import webdriver


def appium_android():
    #配置手机及对应的包
    test_android = {
        "platformName": "Android",
        "platformVersion": "11",
        "deviceName": "M2102K1AC",
        "appPackage": "com.autonavi.minimap",
        "appActivity": "com.autonavi.map.activity.NewMapActivity",
        "resetKeyboard":True,
        "unicodeKeyboard":True
    }

    #建一个driver
    driver = webdriver.Remote('http://localhost:4723/wd/hub',test_android)

    #定位元素并操作
    el1 = driver.find_element_by_id("com.autonavi.minimap:id/agree")
    el1.click()
    el2 = driver.find_element_by_id("com.lbe.security.miui:id/permission_allow_foreground_only_button")
    el2.click()
    el3 = driver.find_element_by_id("com.lbe.security.miui:id/permission_allow_foreground_only_button")
    el3.click()
    el4 = driver.find_element_by_id("com.lbe.security.miui:id/permission_allow_foreground_only_button")
    el4.click()
    el5 = driver.find_element_by_id("com.autonavi.minimap:id/enter_amap")
    el5.click()
    el6 = driver.find_element_by_accessibility_id("查找地点、公交、地铁")
    el6.click()
    el7 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout[5]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.EditText[2]")
    el7.send_keys("宝安中心")
    el8 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout[5]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.LinearLayout/android.support.v7.widget.RecyclerView/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[2]/android.widget.ImageView")
    el8.click()
    el9 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[4]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.ImageView")
    el9.click()
    el10 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[4]/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[3]")
    el10.click()
    el12 = driver.find_element_by_id("com.autonavi.minimap:id/confirm")
    el12.click()

    #关闭driver
    driver.quit()

if __name__ == '__main__':
    appium_android()