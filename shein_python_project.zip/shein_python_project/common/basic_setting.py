import csv
import os
import requests
import json
import datetime


class BasicSetting():
    def __init__(self):
        # test=测试环境，线上环境为pro，灰度环境为gray
        self.shein_env = 'test'
        # 设置shein/romwe
        self.type = 'romwe'
        # 设置站点,主要是us,other,sa
        # self.country_list= {"us","fr","ca","other"}
        # 直播闪购是否开启 0=不开启 1=开启 不能为空
        self.open_flash = '1'
        # 统一登录的验证码
        self.valid_code = ''
        # 当前父目录
        self.base_path = os.path.abspath('..')

    def select_id(self):
        '''
        直播选品id，当没有配置闪购活动时，选品id才生效，且展示在直播预告&直播间的商品列表里
        :return:
        '''
        # open_flash = BasicSetting().open_flash()
        select_id = ''
        if self.type == 'romwe':
            select_id = '01400903'
        elif self.type == 'shein':
            if self.open_flash == '0':
                select_id = '00200209'
            elif self.open_flash == '1':
                select_id = ''
        return select_id

    def youtube_video(self):
        '''
        从youtube中获取shein相关的视频id
        :return:
        '''
        url = 'https://www.youtube.com/youtubei/v1/search?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'
        data = {
            "context": {
                "client": {
                    "hl": "zh-CN",
                    "gl": "US",
                    "remoteHost": "148.153.145.26",
                    "deviceMake": "",
                    "deviceModel": "",
                    "visitorData": "CgtVWEpqZVRqYTcwYyi6i7qHBg%3D%3D",
                    "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                                 "Chrome/91.0.4472.124 Safari/537.36,gzip(gfe)",
                    "clientName": "WEB",
                    "clientVersion": "2.20210712.07.00",
                    "osName": "Windows",
                    "osVersion": "10.0",
                    "originalUrl": "https://www.youtube.com/results?search_query=shein",
                    "screenPixelDensity": 1,
                    "platform": "DESKTOP",
                    "clientFormFactor": "UNKNOWN_FORM_FACTOR",
                    "screenDensityFloat": 1.25,
                    "timeZone": "Asia/Shanghai",
                    "browserName": "Chrome",
                    "browserVersion": "91.0.4472.124",
                    "screenWidthPoints": 1536,
                    "screenHeightPoints": 722,
                    "utcOffsetMinutes": 480,
                    "userInterfaceTheme": "USER_INTERFACE_THEME_LIGHT",
                    "mainAppWebInfo": {
                        "graftUrl": "/results?search_query=shein",
                        "webDisplayMode": "WEB_DISPLAY_MODE_BROWSER",
                        "isWebNativeShareAvailable": "true"
                    }
                },
                "user": {
                    "lockedSafetyMode": "false"
                },
                "request": {
                    "useSsl": "true",
                    "internalExperimentFlags": [],
                    "consistencyTokenJars": []
                },
                "clickTracking": {
                    "clickTrackingParams": "CB0Q7VAiEwjQ1rbggeLxAhVRno8KHTNYCxM="
                },
                "adSignalsInfo": {
                    "params": [{
                        "key": "dt",
                        "value": "1626244539780"
                    }, {
                        "key": "flash",
                        "value": "0"
                    }, {
                        "key": "frm",
                        "value": "0"
                    }, {
                        "key": "u_tz",
                        "value": "480"
                    }, {
                        "key": "u_his",
                        "value": "6"
                    }, {
                        "key": "u_java",
                        "value": "false"
                    }, {
                        "key": "u_h",
                        "value": "864"
                    }, {
                        "key": "u_w",
                        "value": "1536"
                    }, {
                        "key": "u_ah",
                        "value": "824"
                    }, {
                        "key": "u_aw",
                        "value": "1536"
                    }, {
                        "key": "u_cd",
                        "value": "24"
                    }, {
                        "key": "u_nplug",
                        "value": "3"
                    }, {
                        "key": "u_nmime",
                        "value": "4"
                    }, {
                        "key": "bc",
                        "value": "31"
                    }, {
                        "key": "bih",
                        "value": "722"
                    }, {
                        "key": "biw",
                        "value": "1520"
                    }, {
                        "key": "brdim",
                        "value": "0,0,0,0,1536,0,1536,824,1536,722"
                    }, {
                        "key": "vis",
                        "value": "1"
                    }, {
                        "key": "wgl",
                        "value": "true"
                    }, {
                        "key": "ca_type",
                        "value": "image"
                    }],
                    "bid": "ANyPxKrVFrCPfEqCd9qcFwu7nQC5mWU5GwcAk5NyknPqGvv2xZbF0QkzOWmmpnSu2kFu-eG5g3reKF-08JHb6ANkBptTdlLV5g"
                }
            },
            "query": "shein",
            "webSearchboxStatsUrl":
                "/search?oq=shein&gs_l=youtube.12...0.0.1.2391650.0.0.0.0.0.0.0.0..0.0....0...1ac..64.youtube..0.0.0....0.aSHqN3o7jCA"
        }
        re = requests.post(url, data=json.dumps(data))
        videoId_one = \
            re.json()['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer'][
                'contents'][
                0]['itemSectionRenderer']['contents'][0]['videoRenderer']['videoId']
        videoId_sec = \
            re.json()['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer'][
                'contents'][
                0]['itemSectionRenderer']['contents'][1]['videoRenderer']['videoId']
        return videoId_one, videoId_sec

    def coupon_code(self):
        '''
        优惠券，配直播活动时使用
        :return:
        '''
        # shein_env = BasicSetting().shein_env()
        # type=BasicSetting().type()
        coupon_code = ''
        if self.type == 'shein':
            if self.shein_env == 'test':
                coupon_code = 'jianxun'
            else:
                coupon_code = 'oxm3'
        elif self.type == 'romwe':
            if self.shein_env == 'test':
                coupon_code = 'g0Aaw3XTpa'
            elif self.shein_env == 'gray':
                coupon_code = 'qca081612'
            elif self.shein_env == 'pro':
                coupon_code = 'oxm3'
        return coupon_code

    def live_goods_id(self):
        '''
        直播回放的商品
        :return:
        '''
        # shein_env = BasicSetting().shein_env()
        live_goods_id = []
        if self.type=='shein':
            if self.shein_env == 'test':
                live_goods_id = [270766, 517449, 515035]
            else:
                live_goods_id = [2618824, 2564697, 2695964, 2765920, 2695895, 2695965]
        elif self.type=='romwe':
            if self.shein_env == 'test':
                live_goods_id = [270766, 329632, 337998]
            else:
                live_goods_id = [2618824, 2564697, 2695964, 2765920, 2695895, 2695965]
        return live_goods_id

    def header_json(self):
        '''
        json的请求头
        :return:
        '''
        header_json = {
            'accept': 'application/json, text/plain, */*',
            'accept-encoding': 'gzip, deflate, br',
            'content-type': 'application/json;charset=UTF-8',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/91.0.4472.114 Safari/537.3'
        }
        return header_json

    def header_shein_app_login(self):
        '''
        shein_app的请求头
        :return:
        '''
        header_shein_app = {
            'SiteUID': 'app',
            'LocalCountry': 'US',
            'AppVersion': '7.5.0',
            'skipGeetest': '1'
        }
        return header_shein_app

    def header_app_token(self):
        '''
        携带app_token的请求头
        :return:
        '''
        shein_app_token = BasicSetting().app_login()
        header_app_token = {
            'deviceid': '5df652aec2cd07df6db49c9928225e6f',
            'applanguage': 'en',
            'siteuid': 'app',
            'token': shein_app_token
        }
        return header_app_token

    def app_login(self):
        '''
        app登录接口，获取app的token
        :return:
        '''
        # app_env=BasicSetting().shein_env()
        app_api = BasicSetting().app_api()
        header = BasicSetting().header_shein_app_login()
        url = app_api + '/user/common_login'
        data = {
            'challenge': '4c9855cc6707434e589d27b597b85891',
            'email': 'yu123@gmail.com',
            'password': 'nb5065NB*',
            'validate': '1',
            'risk_id': '1'
        }
        res = requests.post(url, data=data, headers=header)
        shein_app_tokne = res.json()['info']['member']['token']
        return shein_app_tokne

    def app_api(self):
        '''
        不同环境下app相关的api
        :return:
        '''
        # app_env=BasicSetting().shein_env()
        # type=BasicSetting().type()
        if self.type == 'shein':
            if self.shein_env == 'test':
                app_api = 'http://api-service-test01.shein.com'
            elif self.shein_env == 'gray':
                app_api = 'http://api-service-gray01.shein.com'
            elif self.shein_env == 'pro':
                app_api = 'https://api-service.shein.com'
        elif self.type == 'romwe':
            if self.shein_env == 'test':
                app_api = 'http://api-service-test01.romwe.com'
            elif self.shein_env == 'gray':
                app_api = 'http://api-service-gray01.romwe.com'
            elif self.shein_env == 'pro':
                app_api = 'https://api-service.romwe.com'
        return app_api

    def ulp_api(self):
        '''
        ulp_api=统一登录api
        :return:
        '''
        # shein_env = BasicSetting().shein_env()
        if self.shein_env == 'test':
            ulp_api = 'http://ulp-test01.sheincorp.cn/web'
        elif self.shein_env == 'pro':
            ulp_api = 'https://ulp.sheincorp.cn/api'
        elif self.shein_env == 'gray':
            ulp_api = 'https://ulp.sheincorp.cn/api'
        elif self.shein_env == 'usa_pro':
            ulp_api = 'https://ulp.sheincorp.cn/api'
        return ulp_api

    def social_api(self):
        '''
        socail_api=社区后台api
        :return:
        '''
        if self.shein_env == 'test':
            socail_api = 'https://gw-admin-api-test01.biz.sheincorp.cn/test01'
        elif self.shein_env == 'pro':
            socail_api = 'https://gw-admin-api.biz.sheincorp.cn'
        elif self.shein_env == 'gray':
            socail_api = 'https://gw-admin-api-gray01.biz.sheincorp.cn/gray01'
        elif self.shein_env == 'usa_pro':
            socail_api = 'https://gw-admin-api.biz.sheinbackend.com/gray-us'
        return socail_api

    def ulp_token(self):
        '''
        获取统一登录的token
        :return:
        '''

        # 半小时内不再重新调用
        curr_time = datetime.datetime.now()
        str_curr_time = curr_time.strftime('%Y%m%d%H%M%S')
        time_v_path = os.path.join(self.base_path, 'test_data', 'time_v.csv')
        # print(time_v_path)
        with open(r'F:\shein_python_project\test_data\time_v.csv', mode='r') as r_f:
            ff = csv.reader(r_f)
            ff_list = list(ff)
            time_v = ff_list[0][0]
            # 判断该接口是否在半个小时前执行过
            if int(time_v) - int(str_curr_time) > 0:
                r_f.close()
            else:
                time_str = (curr_time + datetime.timedelta(hours=0.5)).strftime('%Y%m%d%H%M%S')
                w_f = open(r'F:\shein_python_project\test_data\time_v.csv', mode='w', newline='')
                d = csv.writer(w_f)
                d.writerow([time_str])
                w_f.close()
                # 接口请求
                ulp_url = BasicSetting().ulp_api() + '/auth/login'
                header = BasicSetting().header_json()
                ulp_data = {
                    "ip": "10.0.0.0", "name": "yushuohuan", "password": "nb5065NB**", "valid_code": self.valid_code,
                    "system": "ULP",
                    "token": ''
                }
                ulp_re = requests.post(ulp_url, data=json.dumps(ulp_data), headers=header)
                ulp_token = ulp_re.json()['info']['token']
                ulp_token_path = os.path.join(self.base_path, 'test_data', 'ulp_token.csv')
                # print(ulp_token_path)
                ulp_token_f = open(r'F:\shein_python_project\test_data\ulp_token.csv', mode='w', newline='')
                ulp_token_d = csv.writer(ulp_token_f)
                ulp_token_d.writerow([ulp_token])
                ulp_token_f.close()

    def social_token(self):
        '''
        获取社区后台系统的token
        :return:
        '''
        BasicSetting().ulp_token()
        ulp_token_path = os.path.join(self.base_path, 'test_data', 'ulp_token.csv')
        with open(r'F:\shein_python_project\test_data\ulp_token.csv', mode='r') as r_f:
            ff = csv.reader(r_f)
            ff_list = list(ff)
            ulp_token = ff_list[0][0]
        social_login_url = BasicSetting().social_api() + '/social-admin/auth/login/ulp'
        heaer = BasicSetting().header_json()
        social_login_data = {
            'token': ulp_token
        }
        social_re = requests.post(social_login_url, data=json.dumps(social_login_data), headers=heaer)
        social_token = social_re.json()['info']['data']['token']
        r_f.close()
        return social_token

    def header_social_token(self):
        '''
        带有社区后台token的请求头
        :return:
        '''
        social_token = BasicSetting().social_token()
        header_social_token = {
            'accept': 'application/json, text/plain, */*',
            'accept-encoding': 'gzip, deflate, br',
            'content-type': 'application/json;charset=UTF-8',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
            'x-gw-name': '4%BD%99%E7%A1%95%E7%84%95',
            'x-gw-token': social_token
        }
        return header_social_token

    def header_upload(self):
        '''
        上传图片的请求头
        :return:
        '''
        social_token = BasicSetting().social_token()
        header_upload = {
            'x-gw-name': '4%BD%99%E7%A1%95%E7%84%95',
            'x-gw-token': social_token,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/91.0.4472.114 Safari/537.36'
        }
        return header_upload

# if __name__ =='__main__':
#     BasicSetting().ulp_token()
