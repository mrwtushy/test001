from common.basic_setting import BasicSetting
import csv
import requests
import json
import datetime
import os


class DataSetting(BasicSetting):
    def __init__(self):
        super(DataSetting, self).__init__()
        # 读取直播ID
        data_shein_live_id_path = os.path.join(self.base_path, 'test_data', 'data_shein_live_id.csv')
        with open(r'F:\shein_python_project\test_data\data_shein_live_id.csv', mode='r') as f:
            ff = csv.reader(f)
            ff_list = list(ff)
            self.shein_live_id = ff_list[0][0]
            f.close()
        if self.type=='shein':
            self.belong='0'
        elif self.type=='romwe':
            self.belong = '1'

    def data_creat_live_shein(self):
        '''
        创建直播数据body
        :return:
        '''
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y-%m-%d %H:%M:%S')
        if self.shein_env=='usa_pro':
            time_name='us'+time_str
        else:
            time_name='nous'+time_str
        select_id = BasicSetting().select_id()
        live_goods_id = BasicSetting().live_goods_id()
        if self.type=='shein':
            data_creat_live = {"live_title":"shein自动化专用"+time_name,"description":"这是Live description","is_test":1,
                               "expected_live_start_time":1642576953,"open_flash":self.open_flash,
                               "select_id":select_id,"pre_banner_img_id":2484,"pre_banner_vertical_img_id":2880,
                               "head_portrait_img_id":'',"background_img_id":2852,"live_video_id":"kpEW7Dnkg4g",
                               "is_livestream":1,"discount_info":"这是直播描述这是直播描述这是直播描述","live_stream_format":1,
                               "list_goods_id":[],"pre_vertical":1,"label_list":[],
                               "region_country":[{"region":1,"country_list":["us","fr","ca","other"]},
                                                 {"region":2,"country_list":["sa"]}],
                               "live_preview_module_req":{"show_follow_info":1,"pre_video_id":"ADut15VA41Y",
                                                          "pre_stream_format":1},
                               "live_module_req":{"is_livestream":1,"live_video_id":"kpEW7Dnkg4g",
                                                  "live_stream_format":1,"discount_info":"这是直播描述这是直播描述这是直播描述",
                                                  "goods_id":live_goods_id},"belong":self.belong}
        elif self.type=='romwe':
            data_creat_live={"live_title":"romwe自动化专用"+time_name,"description":"这是Live description","is_test":1,
                             "expected_live_start_time":1642576953,"open_flash":0,"select_id":select_id,
                             "pre_banner_img_id":2484,"pre_banner_vertical_img_id":2876,"head_portrait_img_id":'',
                             "background_img_id":2484,"live_video_id":"kpEW7Dnkg4g","is_livestream":1,
                             "discount_info":"这是直播描述这是直播描述这是直播描述","live_stream_format":1,"list_goods_id":[],
                             "pre_vertical":1,"label_list":[],"country_list":["fr","us","mx","ca","gb"],
                             "live_preview_module_req":{"show_follow_info":1,"pre_video_id":"ADut15VA41Y",
                                                        "pre_stream_format":1,"pre_goods_id":live_goods_id},
                             "live_module_req":{"is_livestream":1,"live_video_id":"kpEW7Dnkg4g","live_stream_format":1,
                                                "discount_info":"这是直播描述这是直播描述这是直播描述",
                                                "goods_id":live_goods_id},"belong":self.belong}
        # print(data_creat_live)
        return data_creat_live

    # def read_shein_live_id(self):
    #     '''
    #     读取shein直播id
    #     :return:
    #     '''
    #     with open(r'/Users/yusheng/Documents/shein_python_project/test_data/data_shein_live_id.csv', mode='r') as f:
    #         ff = csv.reader(f)
    #         ff_list = list(ff)
    #         shein_live_id = ff_list[0][0]
    #         f.close()
    #     return shein_live_id

    def data_common_social_live_shein(self):
        '''
        通用请求body
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        data_social_live_common_shein = {
            'id': self.shein_live_id,
            'belong': self.belong
        }
        return data_social_live_common_shein

    def data_common_live_start(self):
        '''共用活动开启请求参数'''
        # live_id=DataSetting().read_shein_live_id()
        if self.type=='shein':
            data_common_live_start = {'live_id': self.shein_live_id, 'password': 'shein'}
        elif self.type=='romwe':
            data_common_live_start = {'live_id': self.shein_live_id, 'password': 'romwe'}
        return data_common_live_start

    def data_prize_draw(self):
        '''
        创建抽奖Prize Draw-积分，优惠券，礼品卡
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        coupon_code = BasicSetting().coupon_code()
        data_prize_draw = {"list": [{"prize_type": 0, "number": 1, "points": 10, "rounds": 1, "description": "抽积分",
                                     "uid_list": [], "live_id":
                                         self.shein_live_id}, {"prize_type": 2, "number": 1, "points": "", "rounds": 2,
                                                               "coupon_code": coupon_code,
                                                               "description": "抽优惠券", "uid_list": [],
                                                               "live_id": self.shein_live_id},
                                    {"prize_type": 3, "number": 1, "points": "", "rounds": 3, "description": "抽礼品卡",
                                     "uid_list": [],
                                     "live_id": self.shein_live_id}], "belong": self.belong}
        return data_prize_draw

    def data_creat_redpacket(self):
        '''
        创建抢红包Points Giveaway-随机，平均积分
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        data_creat_redpacket = {"list": [{"envelope_type": 0, "number": 2, "rounds": 1, "description": "随机积分",
                                          "live_id": self.shein_live_id, "points": 10},
                                         {"envelope_type": 1, "number": 2, "rounds": 2, "description": "平均积分",
                                          "live_id": self.shein_live_id, "points": 10}], "belong": self.belong}
        return data_creat_redpacket

    def data_create_box(self):
        '''
        创建礼盒雨GIFT BOX RAIN
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        coupon_code = BasicSetting().coupon_code()
        data_create_box = {"live_id": self.shein_live_id, "description": "礼盒雨", "options":
            [{"gift_comment": "1", "description": "积分", "gift_type": 1, "rate": 90, "total": 5, "points": "1"},
             {"gift_comment": "优惠券", "description": "优惠券", "gift_type": 2, "rate": 10, "total": 0,
              "coupon_code": coupon_code}],
                           "belong": self.belong}
        return data_create_box

    def data_create_vote(self):
        '''
        创建投票
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        # 创建投票-图片VOTE
        data_create_vote_picture = {"comment": "图片投票", "is_show": 1, "vote_type": 1, "options":
            [{"init_number": 0, "goods_id": "", "option_id": 0, "sku": "",
              "vote_img": "http://img.ltwebstatic.com/images3_outfit/2021/06/28/1624885486f4c2b20e6fff0c4fbdea19453b8a98e9_thumbnail_500x500.jpg",
              "vote_text": "", "options": "21e499a2f2b64a4fb7f326a0af16be2c"},
             {"init_number": 0, "goods_id": "", "option_id": 0, "sku": "",
              "vote_img": "http://img.ltwebstatic.com/images3_outfit/2021/06/28/1624885495e4fccee70f2b7cb56f6ea5480a76243d_thumbnail_500x500.jpg",
              "vote_text": "", "options": "ee7768d5237243ef8ec62d43a47c955c"}], "vote_id": "",
                                    "live_id": self.shein_live_id,
                                    "belong": self.belong}
        # 创建投票-商品VOTE
        data_create_vote_product = {
            "comment": "商品",
            "is_show": 1,
            "vote_type": 2,
            "options": [{
                "init_number": 0,
                "goods_id": 1688992,
                "option_id": 0,
                "sku": "swpants04201007514",
                "vote_img": "http://img.ltwebstatic.com/images3_pi/2020/10/15/16027514017319181fd5c896c3f33c0a11eb8a0f39_thumbnail_450x450.jpg",
                "vote_text": ""
            }, {
                "init_number": 0,
                "goods_id": 1910692,
                "option_id": 0,
                "sku": "swpants04201126411",
                "vote_img": "http://img.ltwebstatic.com/images3_pi/2020/11/27/16064552260631919aa529552327482d5f97ea64d6_thumbnail_450x450.jpg",
                "vote_text": ""
            }],
            "vote_id": "",
            "live_id": self.shein_live_id,
            "belong": 0
        }
        # 创建投票-文字-有初始人数VOTE
        data_create_vote_text = {"comment": "文字", "is_show": 1, "vote_type": 0, "options":
            [{"init_number": 1, "goods_id": "", "option_id": 0, "sku": "", "vote_img": "", "vote_text": "文字1"},
             {"init_number": 2, "goods_id": "", "option_id": 0, "sku": "", "vote_img": "", "vote_text": "文字2"}],
                                 "vote_id": "", "live_id": self.shein_live_id, "belong": 0}

        return data_create_vote_picture, data_create_vote_product, data_create_vote_text

    def data_creat_official_message(self):
        '''发送直播官方消息'''
        # shein_live_id = DataSetting().read_shein_live_id()
        data_creat_official_message = {
            "content": "sys_messagesys_messagesys_messagesys_messagesys_messagesys_messagesys_"
                       "messagesys_messagesys_messagesys_messagesys_messagesys_messagesys_"
                       "messagesys_messagesys_messagesys_messagesys_messagesys_messagesy",
            "live_id": self.shein_live_id, "is_pin": 1, "belong": self.belong}
        return data_creat_official_message

    def data_goods_show_one(self):
        '''设置单个直播的悬浮商品'''
        # shein_live_id = DataSetting().read_shein_live_id()
        goods_one = DataSetting().live_goods_list()[0]
        data_goods_show_one = {"live_id": self.shein_live_id, "id_list": [goods_one], "belong": self.belong}
        return data_goods_show_one

    def data_goods_show_more(self):
        '''设置多个直播的悬浮商品'''
        # shein_live_id = DataSetting().read_shein_live_id()
        goods_one = DataSetting().live_goods_list()[0]
        goods_sec = DataSetting().live_goods_list()[1]
        goods_third = DataSetting().live_goods_list()[2]
        data_goods_show_more = {"live_id": self.shein_live_id, "id_list": [goods_one, goods_sec, goods_third],
                                "belong": self.belong}
        return data_goods_show_more

    def live_goods_list(self):
        '''
        获取直播商品列表
        :return:
        '''
        # shein_live_id = DataSetting().read_shein_live_id()
        social_api = BasicSetting().social_api()
        header = BasicSetting().header_social_token()
        url = social_api + '/social-admin/live/goods/goods-list?belong=0&live_id=' + self.shein_live_id + '&page_number=1&page_size=20'
        re = requests.get(url, headers=header)
        product_one = re.json()['info']['pageResult'][0]['id']
        product_sec = re.json()['info']['pageResult'][1]['id']
        product_third = re.json()['info']['pageResult'][2]['id']

        return product_one, product_sec, product_third

    def mutil_upload_img(self):
        '''上传图片'''
        self.socail_api = BasicSetting().social_api()
        self.header_upload = BasicSetting().header_upload()
        self.url = self.socail_api + '/social-admin/file/upload/mutil-upload-img'
        data = {
            'upload_type': 0
        }
        file_one = {
            'file': open(r'F:\shein_python_project\test_data\mutil_upload_img\111.jpg', 'rb')
        }
        file_sec = {
            'file': open(r'F:\shein_python_project\test_data\mutil_upload_img\222.jpeg', 'rb')
        }
        file_third = {
            'file': open(r'F:\shein_python_project\test_data\mutil_upload_img\333.jpeg', 'rb')
        }
        re_one = requests.post(self.url, data=data, files=file_one, headers=self.header_upload)
        re_sec = requests.post(self.url, data=data, files=file_sec, headers=self.header_upload)
        re_third = requests.post(self.url, data=data, files=file_third, headers=self.header_upload)
        image_key_one = re_one.json()['info']['image_key_list'][0]['image_key']
        image_key_sec = re_sec.json()['info']['image_key_list'][0]['image_key']
        image_key_third = re_third.json()['info']['image_key_list'][0]['image_key']
        return image_key_one, image_key_sec, image_key_third

    def create_push_material(self):
        '''社区后台-直播间-添加推流素材'''
        mutil_upload_img = DataSetting().mutil_upload_img()
        image_key_one = mutil_upload_img[0]
        image_key_sec = mutil_upload_img[1]
        image_key_third = mutil_upload_img[2]
        # shein_live_id = DataSetting().read_shein_live_id()
        self.socail_api = BasicSetting().social_api()
        self.header = BasicSetting().header_social_token()
        self.url = self.socail_api + '/social-admin/live/push/create-push-material'
        self.data = {"img_key_list": [image_key_one, image_key_sec, image_key_third], "live_id": self.shein_live_id,
                     "belong": self.belong}
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)

    def find_push_material(self):
        '''直播推流素材列表-获取素材id'''
        DataSetting().create_push_material()
        # shein_live_id = DataSetting().read_shein_live_id()
        header = BasicSetting().header_social_token()
        url = BasicSetting().social_api() + '/social-admin/live/push/find-push-material?belong=0&live_id=' + self.shein_live_id
        re = requests.get(url, headers=header)
        material_id_one = re.json()['info']['pageResult'][0]['id']
        material_id_sec = re.json()['info']['pageResult'][1]['id']
        material_id_third = re.json()['info']['pageResult'][2]['id']
        return material_id_one, material_id_sec, material_id_third

    def data_start_push_message(self):
        '''开始推流body'''
        # shein_live_id = DataSetting().read_shein_live_id()
        material_id = DataSetting().find_push_material()
        material_id_one = material_id[0]
        material_id_sec = material_id[1]
        material_id_third = material_id[2]
        data_start_push_message_one = {"live_id": self.shein_live_id, "material_id": material_id_one, "sequence": 1,
                                       "belong": self.belong}
        data_start_push_message_sec = {"live_id": self.shein_live_id, "material_id": material_id_sec, "sequence": 2,
                                       "belong": self.belong}
        data_start_push_message_third = {"live_id": self.shein_live_id, "material_id": material_id_third, "sequence": 3,
                                         "belong": self.belong}
        return data_start_push_message_one, data_start_push_message_sec, data_start_push_message_third

    def data_send_preview_comment(self):
        '''
        app发送预告弹幕
        :return:
        '''
        # liveId=DataSetting().read_shein_live_id()
        data_send_preview_comment = {
            'originalContent': 'pre this live like this live like this live like this live '
                               'like this live like this live like this live like this live like '
                               'this live like this live like this live like this live like this live like',
            'liveId': self.shein_live_id,
            'nickname': 'yu123'
        }
        return data_send_preview_comment

    def data_test_im_comment_message(self):
        '''
        直播间发送弹幕
        :return:
        '''
        # liveId=DataSetting().read_shein_live_id()
        data_test_im_comment_message = {
            'content': 'like this live like this live like this live like this live like this live like this live like '
                       'this live like this live like this live like this live like this live like this live like this live like',
            'liveId': self.shein_live_id,
            'nickname': 'yu123'
        }
        return data_test_im_comment_message

    def find_prize(self):
        '''查后台直播间抽奖列表'''
        # live_id=DataSetting().read_shein_live_id()
        header = BasicSetting().header_social_token()
        url = BasicSetting().social_api() + '/social-admin/live/prize/find-prize?belong=0&page_number=1&page_size=20&live_id=' + self.shein_live_id
        res = requests.get(url, headers=header)
        jifen_id = res.json()['info']['data']['live_prize_data'][0]['id']
        return jifen_id

    def data_send_point(self):
        '''
        发送抽奖积分
        :return:
        '''
        jifen_id = DataSetting().find_prize()
        data_send_point = {
            "id": jifen_id, "belong": self.belong
        }
        return data_send_point

    def find_comments(self):
        '''
        社区后台-直播间获取评论列表
        :return:
        '''
        # live_id=DataSetting().read_shein_live_id()
        url = BasicSetting().social_api() + '/social-admin/live/comment/find-comments?last_id=0&limit=100&live_id=' + self.shein_live_id+'&belong='+self.belong
        header = BasicSetting().header_social_token()
        re = requests.get(url, headers=header)
        res = re.json()['info']['comments'][0]
        device_id = res['device_id']
        nickname = res['nickname']
        uid = res['uid']
        comment_id = res['id']
        return device_id, nickname, uid, comment_id

    def data_comment_send_points(self):
        '''对评论进行发积分'''
        # live_id=DataSetting().read_shein_live_id()
        uid = DataSetting().find_comments()[2]
        comment_id = DataSetting().find_comments()[3]
        data_comment_send_points = {"user_info_list": [{"uid": uid, "comment_id": comment_id}], "belong": self.belong,
                                    "live_id": self.shein_live_id}
        return data_comment_send_points

    def data_add_blacklist(self):
        '''社区后台-直播间评论拉黑'''
        uid = DataSetting().find_comments()[2]
        nickname = DataSetting().find_comments()[1]
        device_id = DataSetting().find_comments()[0]
        data_add_blacklist = {"blacklist": [{"uid": uid, "nickname": nickname, "device_id": device_id}], "belong": self.belong}
        return data_add_blacklist

    def data_delete_blacklist(self):
        '''社区后台-直播间取消拉黑'''
        uid = DataSetting().find_comments()[2]
        data_delete_blacklist = {"uid": uid, "belong": self.belong}
        return data_delete_blacklist

# if __name__ == '__main__':
#     DataSetting().find_comments()
