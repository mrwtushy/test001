from BSTestRunner import BSTestRunner
import unittest
import time



# 指定测试用例和测试报告的路径
test_dir= r'/test_suite'
report_dir=r'/Users/yusheng/Downloads/shein_python_project/test_report'
# 加载测试用例
discover=unittest.defaultTestLoader.discover(test_dir)
# 定义报告的文件格式
now=time.strftime("%Y-%m-%d")
now1=time.strftime('%H_%M_%S')
reports_name=report_dir+'/'+now+'~'+now1+' '+'hlwhy_report.html'
# 运行用例并生成测试报告
with open(reports_name,'wb') as f:
    runner=BSTestRunner(stream=f,title='海外版接口自动化测试报告',description='用例执行情况如下')
    runner.run(discover)