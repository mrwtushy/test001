import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class CreateVote(unittest.TestCase):
    def setUp(self):
        print('创建投票')

    def tearDown(self):
        pass

    def test_create_vote_picture(self):
        '''创建投票-图片VOTE'''
        print('创建图片投票')
        self.url = BasicSetting().social_api() + '/social-admin/live/vote/createVote'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_create_vote()[0]
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')

    def test_create_vote_product(self):
        '''创建投票-商品VOTE'''
        print('创建商品投票')
        self.url = BasicSetting().social_api() + '/social-admin/live/vote/createVote'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_create_vote()[1]
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')

    def test_create_vote_text(self):
        '''创建投票-文字-有初始人数VOTE'''
        print('创建文字投票')
        self.url = BasicSetting().social_api() + '/social-admin/live/vote/createVote'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_create_vote()[2]
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
