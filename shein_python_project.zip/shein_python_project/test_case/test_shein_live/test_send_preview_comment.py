import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class SendPreviewComment(unittest.TestCase):
    def setUp(self):
        print('app发送预告弹幕')

    def tearDown(self):
        pass

    def test_shein(self):
        '''app发送预告弹幕'''
        print('app发送预告弹幕')

        self.url = BasicSetting().app_api() + '/social/live/comment/send-preview-comment'
        self.header = BasicSetting().header_app_token()
        self.data = DataSetting().data_send_preview_comment()
        re = requests.post(self.url, data=self.data, headers=self.header)
        execute_v = 'ok'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
