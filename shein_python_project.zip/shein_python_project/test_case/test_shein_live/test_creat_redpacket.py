import requests
import unittest
import json
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class CreatRedpacket(unittest.TestCase):
    def setUp(self):
        print('创建抢红包Points Giveaway-随机，平均积分')

    def tearDown(self):
        pass

    def test_creat_redpacket(self):
        '''创建抢红包Points Giveaway-随机，平均积分'''
        print('创建抢红包Points Giveaway-随机，平均积分')

        self.url = BasicSetting().social_api() + '/social-admin/live/redpacket/batch-creat-redpacket'
        self.token_header = BasicSetting().header_social_token()
        self.data_creat_redpacket = DataSetting().data_creat_redpacket()
        creat_live_re = requests.post(self.url, data=json.dumps(self.data_creat_redpacket),
                                      headers=self.token_header)
        execute_v = 200
        actual_v = creat_live_re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
