import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class StartNextBox(unittest.TestCase):
    def setUp(self):
        print('开始礼盒雨')

    def tearDown(self):
        pass

    def test_shein(self):
        '''开始礼盒雨'''
        print('开始礼盒雨')

        self.url = BasicSetting().social_api() + '/social-admin/live/gift/start-next-box'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_common_live_start()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 'OK'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
