import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class CreateBox(unittest.TestCase):
    def setUp(self):
        print('创建礼盒雨GIFT BOX RAIN')

    def tearDown(self):
        pass

    def test_create_box(self):
        '''创建礼盒雨GIFT BOX RAIN'''
        print('创建礼盒雨GIFT BOX RAIN')

        self.url = BasicSetting().social_api() + '/social-admin/live/gift/createBox'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_create_box()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
