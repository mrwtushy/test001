import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class StartPushMessage(unittest.TestCase):
    def setUp(self):
        print('开始推流素材')

    def tearDown(self):
        pass

    def test_start_push_message(self):
        '''开始推流素材'''
        print('开始推流素材')

        self.url = BasicSetting().social_api() + '/social-admin/live/push/start-push-message'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_start_push_message()
        data_one=self.data[0]
        data_sec=self.data[1]
        data_third=self.data[2]
        re_one = requests.post(self.url, data=json.dumps(data_one), headers=self.header)
        re_sec = requests.post(self.url, data=json.dumps(data_sec), headers=self.header)
        re_third = requests.post(self.url, data=json.dumps(data_third), headers=self.header)
        execute_v = 200
        actual_v = re_one.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
