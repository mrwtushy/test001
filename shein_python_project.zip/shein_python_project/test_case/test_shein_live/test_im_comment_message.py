import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class ImCommentMessage(unittest.TestCase):
    def setUp(self):
        print('直播间发送弹幕')

    def tearDown(self):
        pass

    def test_shein(self):
        '''直播间发送弹幕'''
        print('直播间发送弹幕')

        self.url = BasicSetting().app_api() + '/social/live/im/comment-message'
        self.header = BasicSetting().header_app_token()
        self.data = DataSetting().data_test_im_comment_message()
        re = requests.post(self.url, data=self.data, headers=self.header)
        execute_v = 'ok'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
