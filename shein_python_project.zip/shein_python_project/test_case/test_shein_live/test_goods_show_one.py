import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class GoodsShowOne(unittest.TestCase):
    def setUp(self):
        print('设置单个直播的悬浮商品')

    def tearDown(self):
        pass

    def test_goods_show_one(self):
        '''设置单个直播的悬浮商品'''
        print('设置单个直播的悬浮商品')

        self.url = BasicSetting().social_api() + '/social-admin/live/goods/show'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_goods_show_one()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
