import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class CreatOfficialMessage(unittest.TestCase):
    def setUp(self):
        print('发送直播官方消息')

    def tearDown(self):
        pass

    def test_creat_official_message(self):
        '''发送直播官方消息'''
        print('发送直播官方消息')

        self.url = BasicSetting().social_api() + '/social-admin/live/officialmessage/creat-official-message'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_creat_official_message()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 200
        actual_v = re.status_code
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
