import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class SendPoint(unittest.TestCase):
    def setUp(self):
        print('发送抽奖积分')

    def tearDown(self):
        pass

    def test_shein(self):
        '''发送抽奖积分'''
        print('发送抽奖积分')

        self.url = BasicSetting().social_api() + '/social-admin/live/prize/send-point'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_send_point()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 'OK'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
