import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class CretaPrizeDraw(unittest.TestCase):
    def setUp(self):
        print('创建抽奖Prize Draw-积分，优惠券，礼品卡')

    def tearDown(self):
        pass

    def test_creat_prize_draw(self):
        '''创建抽奖Prize Draw-积分，优惠券，礼品卡'''
        print('创建抽奖Prize Draw-积分，优惠券，礼品卡')

        self.url = BasicSetting().social_api() + '/social-admin/live/prize/batch-creat-prize'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_prize_draw()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 'OK'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '直播不存在或状态已改变')


if __name__ == '__main__':
    unittest.main()
