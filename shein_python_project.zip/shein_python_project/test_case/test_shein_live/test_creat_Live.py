import requests
import unittest
import json
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting
import csv
import os


class CreatLive(unittest.TestCase):
    def setUp(self):
        print('创建shein直播预告')

    def tearDown(self):
        pass

    def test_creat_live(self):
        '''创建shein直播预告'''
        print('创建shein直播预告')

        self.creat_live_url = BasicSetting().social_api() + '/social-admin/live/creat-Live'
        self.token_header = BasicSetting().header_social_token()
        self.data_creat_live_shein = DataSetting().data_creat_live_shein()
        creat_live_re = requests.post(self.creat_live_url, data=json.dumps(self.data_creat_live_shein),
                                      headers=self.token_header)
        execute_v = 'OK'
        actual_v = creat_live_re.json()['msg']
        self.assertEqual(execute_v, actual_v, '视频ID必须是唯一的')
        shein_live_id = creat_live_re.json()['info']
        f=open(r'F:\shein_python_project\test_data\data_shein_live_id.csv', mode='w', newline='')
        d = csv.writer(f)
        d.writerow([shein_live_id])
        f.close()


if __name__ == '__main__':
    unittest.main()
