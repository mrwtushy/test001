import requests
import json
import unittest
from common.basic_setting import BasicSetting
from common.set_data_shein_live import DataSetting


class AddBlacklist(unittest.TestCase):
    def setUp(self):
        print('社区后台-直播间评论拉黑')

    def tearDown(self):
        pass

    def test_shein(self):
        '''社区后台-直播间评论拉黑'''
        print('社区后台-直播间评论拉黑')

        self.url = BasicSetting().social_api() + '/social-admin/live/comment/add-blacklist'
        self.header = BasicSetting().header_social_token()
        self.data = DataSetting().data_add_blacklist()
        re = requests.post(self.url, data=json.dumps(self.data), headers=self.header)
        execute_v = 'OK'
        actual_v = re.json()['msg']
        self.assertEqual(execute_v, actual_v, '脚本异常')


if __name__ == '__main__':
    unittest.main()
